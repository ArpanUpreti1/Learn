import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

const Page = () => {
  const { id } = useParams();
  const [animeData, setAnimeData] = useState([]);

  useEffect(() => {
    const getAnimeData = async () => {
      const response = await fetch(`https://api.jikan.moe/v4/anime/${id}/full`);
      const data = await response.json();
      const usefulData = data.data;
      setAnimeData(usefulData);
    };

    getAnimeData();
  }, []);


  return (
    <div>
      {
        animeData.length !== 0 ?
          <div>
            <h1 style={{ fontSize: "50px" ,textAlign: "center", fontFamily: "cursive"}}>{animeData.title}</h1>
            <img src={animeData.images.jpg.image_url} alt={animeData.title} />
            <p>Get details from here</p>
            <a href="/">Back to home</a>
          </div>
          : <div>
            <h1>Loading...</h1>
          </div>
      }

    </div>
  );
};

export default Page;
