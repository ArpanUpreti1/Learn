
const NotFound = () => {
  return (
    <div>
        <h1 style={{fontSize: "50px"}}>Page Not Found</h1>
    <a href="/">Back to Home</a>
    </div>
  )
}

export default NotFound