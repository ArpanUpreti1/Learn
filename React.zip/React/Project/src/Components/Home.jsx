// Components/Home.js
import { useState, useEffect } from "react";

const Home = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const getData = async () => {
      const response = await fetch("https://api.jikan.moe/v4/anime");
      const data = await response.json();
      const usefulData = data.data;
      setData(usefulData);
      console.log(usefulData);
    }
    getData();    
  }, [])

  return (
    <>
      <div>
        {data.map((anime) => (
          <div key={anime.mal_id}>
            <a
              href={`./page/${anime.mal_id}`}
              style={{ fontSize: "16px", padding: "4px", color: "blue" }}
            >
              {anime.title}
            </a>
            <img src={anime.images.jpg.image_url} alt={anime.title} style={{ width: "100px", height: "150px" }} />
          </div>
        ))}
      </div>
    </>
  );
};

export default Home;
